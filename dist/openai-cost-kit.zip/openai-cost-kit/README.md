# openai-cost-kit

Cut ChatGPT/OpenAI costs 40–70% without losing quality.

## Quick Start
```bash
bash setup.sh
```

## Manual Steps
- [ ] Paste `platforms/openai/SYSTEM_PROMPT.md` into ChatGPT Project instructions
- [ ] Settings → Personalization → Custom Instructions → paste from `core/OUTPUT_RULES.md`
- [ ] platform.openai.com → Settings → Limits → set monthly spend cap

MIT License
