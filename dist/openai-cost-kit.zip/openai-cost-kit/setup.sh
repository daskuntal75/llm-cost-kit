#!/bin/zsh
set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BOLD='\033[1m'; NC='\033[0m'
ok()   { printf "${GREEN}  ✓${NC}  %s\n" "$1"; }
warn() { printf "${YELLOW}  ⚠${NC}  %s\n" "$1"; }
printf "\n${BOLD}OpenAI / ChatGPT Cost Kit — Setup${NC}\n\n"
if grep -q "OPENAI_API_KEY" ~/.zshrc 2>/dev/null; then ok "OPENAI_API_KEY already set"
else
  printf "  Enter OPENAI_API_KEY (hidden, Enter to skip):\n  → platform.openai.com → API keys\n> "
  read -r -s K; printf "\n"
  [[ -n "$K" ]] && echo "export OPENAI_API_KEY=\"$K\"" >> ~/.zshrc && ok "OPENAI_API_KEY added"
fi
python3 -c "import openai" 2>/dev/null && ok "openai package installed" || \
  pip3 install openai --quiet && ok "openai installed"
printf "\n${BOLD}Manual steps:${NC}\n"
printf "  □  Paste platforms/openai/SYSTEM_PROMPT.md into ChatGPT Project instructions\n"
printf "  □  Settings → Personalization → Custom Instructions → paste from core/OUTPUT_RULES.md\n"
printf "  □  platform.openai.com → Settings → Limits → set monthly spend cap\n"
