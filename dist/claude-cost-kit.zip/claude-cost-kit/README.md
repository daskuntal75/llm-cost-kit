# claude-cost-kit

Cut Claude costs 40–70% without losing quality.
Works with Claude Chat · Claude Code · Cowork.

## Quick Start
```bash
bash setup.sh
source ~/.zshrc
```

## What's Included
| File | Purpose |
|---|---|
| `config.yaml` | Your preferences — edit once |
| `setup.sh` | Installs Claude Code, ccusage, MCP configs, aliases |
| `platforms/claude/CLAUDE.md` | Drop into project root |
| `platforms/claude/SKILL.md` | Install in Cowork → Skills |
| `platforms/claude/mcp-configs/` | 4 context-scoped MCP configs |
| `core/` | Universal principles, output rules, session hygiene |
| `guide.html` | Full interactive guide — open in browser |

## Manual Steps
- [ ] Settings → Memory → confirm ON
- [ ] Settings → User Preferences → paste from `core/OUTPUT_RULES.md`
- [ ] Create Claude Projects, one per context area
- [ ] Cowork → Skills → install `platforms/claude/SKILL.md`
- [ ] Settings → Billing → auto-reload OFF, spend limit set

MIT License
