#!/bin/zsh
set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BOLD='\033[1m'; NC='\033[0m'
ok()   { printf "${GREEN}  ✓${NC}  %s\n" "$1"; }
warn() { printf "${YELLOW}  ⚠${NC}  %s\n" "$1"; }
printf "\n${BOLD}Claude Cost Kit — Setup${NC}\n\n"
command -v claude &>/dev/null && ok "Claude Code: $(claude --version | head -1)" || \
  { npm install -g @anthropic-ai/claude-code && ok "Claude Code installed"; }

command -v ccusage &>/dev/null && ok "ccusage installed" || \
  { npm install -g ccusage && ok "ccusage installed"; }

mkdir -p ~/.claude/mcp-configs
for cfg in mcp-saas mcp-work mcp-infra mcp-default; do
  DST=~/.claude/mcp-configs/${cfg}.json
  SRC="$SCRIPT_DIR/platforms/claude/mcp-configs/${cfg}.json"
  [[ ! -f "$DST" && -f "$SRC" ]] && cp "$SRC" "$DST" && ok "$cfg.json installed"
done

if ! grep -q "claude-saas" ~/.zshrc 2>/dev/null; then
  cat >> ~/.zshrc << 'ALIASES'

# ── claude-cost-kit ───────────────────────────────────────────────────────────
alias claude-saas="claude --mcp-config ~/.claude/mcp-configs/mcp-saas.json"
alias claude-work="claude --mcp-config ~/.claude/mcp-configs/mcp-work.json"
alias claude-infra="claude --mcp-config ~/.claude/mcp-configs/mcp-infra.json"
alias claude-x="claude --mcp-config ~/.claude/mcp-configs/mcp-default.json"
alias cu="ccusage"
alias cu-today="ccusage --since today"
alias agent-brief='echo "{\"task\":\"\",\"constraints\":[],\"inputs\":{},\"output_format\":\"\",\"context\":\"\"}" | pbcopy && echo "Copied"'
# ─────────────────────────────────────────────────────────────────────────────
ALIASES
  ok "Shell aliases added — run: source ~/.zshrc"
fi

printf "\n${BOLD}Manual steps:${NC}\n"
printf "  □  Settings → Memory → confirm ON\n"
printf "  □  Settings → User Preferences → paste from core/OUTPUT_RULES.md\n"
printf "  □  Create Claude Projects (one per context area)\n"
printf "  □  Cowork → Skills → install platforms/claude/SKILL.md\n"
printf "  □  Settings → Billing → auto-reload OFF, spend limit set\n"
printf "\nOpen guide.html in your browser for the full walkthrough.\n"
