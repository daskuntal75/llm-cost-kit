#!/bin/zsh
set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BOLD='\033[1m'; NC='\033[0m'
ok()   { printf "${GREEN}  ✓${NC}  %s\n" "$1"; }
warn() { printf "${YELLOW}  ⚠${NC}  %s\n" "$1"; }
printf "\n${BOLD}Gemini Cost Kit — Setup${NC}\n\n"
if grep -q "GOOGLE_API_KEY" ~/.zshrc 2>/dev/null; then ok "GOOGLE_API_KEY already set"
else
  printf "  Enter GOOGLE_API_KEY (hidden, Enter to skip):\n  → aistudio.google.com → API keys\n> "
  read -r -s K; printf "\n"
  [[ -n "$K" ]] && echo "export GOOGLE_API_KEY=\"$K\"" >> ~/.zshrc && ok "GOOGLE_API_KEY added"
fi
python3 -c "import google.generativeai" 2>/dev/null && ok "google-generativeai installed" || \
  pip3 install google-generativeai --quiet && ok "installed"
printf "\n${BOLD}Manual steps:${NC}\n"
printf "  □  Paste platforms/gemini/GEM_INSTRUCTIONS.md into Gem builder\n"
printf "  □  console.cloud.google.com → Billing → Budgets → set monthly alert\n"
