# gemini-cost-kit

Cut Gemini costs 40–70% without losing quality.

## Quick Start
```bash
bash setup.sh
```

## Manual Steps
- [ ] Paste `platforms/gemini/GEM_INSTRUCTIONS.md` into Gem builder
- [ ] console.cloud.google.com → Billing → Budgets → set monthly alert

MIT License
